// SPDX-FileCopyrightText: The Pion community <https://pion.ly>
// SPDX-License-Identifier: MIT

//go:build !js

package mdns

import (
	"context"
	"net"
	"net/netip"
	"runtime"
	"sync"
	"testing"
	"time"

	"github.com/pion/logging"
	"github.com/pion/transport/v5/test"
	"github.com/stretchr/testify/assert"
	"golang.org/x/net/dns/dnsmessage"
	"golang.org/x/net/ipv4"
	"golang.org/x/net/ipv6"
)

const (
	localAddress = "1.2.3.4"
	isWindows    = runtime.GOOS == "windows"
	isDarwin     = runtime.GOOS == "darwin"
)

func checkIPv4(t *testing.T, addr netip.Addr) {
	t.Helper()
	assert.Truef(t, addr.Is4(), "expected IPv4 for answer but got %s", addr)
}

func checkIPv6(t *testing.T, addr netip.Addr) {
	t.Helper()
	assert.Truef(t, addr.Is6(), "expected IPv6 for answer but got %s", addr)
}

func createListener4(t *testing.T) *net.UDPConn {
	t.Helper()
	addr, err := net.ResolveUDPAddr("udp", DefaultAddressIPv4)
	assert.NoError(t, err)

	sock, err := net.ListenUDP("udp4", addr)
	assert.NoError(t, err)

	// ensure multicast loopback is enabled so tests can observe their own packets.
	_ = ipv4.NewPacketConn(sock).SetMulticastLoopback(true)

	return sock
}

func createListener6(t *testing.T) *net.UDPConn {
	t.Helper()
	addr, err := net.ResolveUDPAddr("udp", DefaultAddressIPv6)
	assert.NoError(t, err)

	sock, err := net.ListenUDP("udp6", addr)
	assert.NoError(t, err)

	// Ensure multicast loopback is enabled so tests can observe their own packets.
	_ = ipv6.NewPacketConn(sock).SetMulticastLoopback(true)

	return sock
}

// firstUsableIPv4Addr returns the first interface that is up, supports multicast,
// is not loopback, and one of its IPv4 addresses. Used to provide a concrete IPv4.
// this is needed for windows because cross-stack ipv4/ipv6 is unreliable.
func firstUsableIPv4Addr(t *testing.T) net.IP {
	t.Helper()
	ifaces, err := net.Interfaces()

	assert.NoError(t, err)
	for _, ifc := range ifaces {
		if ifc.Flags&net.FlagUp == 0 {
			continue
		}
		if ifc.Flags&net.FlagLoopback != 0 {
			continue
		}
		if ifc.Flags&net.FlagMulticast == 0 {
			continue
		}
		addrs, err := ifc.Addrs()

		assert.NoError(t, err)

		for _, a := range addrs {
			var ip net.IP
			switch v := a.(type) {
			case *net.IPNet:
				ip = v.IP
			case *net.IPAddr:
				ip = v.IP
			}
			if ip == nil {
				continue
			}
			if v4 := ip.To4(); v4 != nil {
				return v4
			}
		}
	}

	assert.Fail(t, "no usable IPv4 interface found for test")

	return nil
}

// darwinMulticastOpts returns server options that restrict to loopback
// interfaces on macOS. macOS 15+ Local Network Privacy silently drops
// multicast on non-loopback interfaces in headless CI environments.
// Returns nil on other platforms.
// See https://github.com/actions/runner-images/issues/10924.
func darwinMulticastOpts(t *testing.T) []ServerOption {
	t.Helper()

	if !isDarwin {
		return nil
	}

	ifaces, err := net.Interfaces()
	assert.NoError(t, err)

	var loopback []net.Interface
	for _, ifc := range ifaces {
		if ifc.Flags&net.FlagLoopback != 0 {
			loopback = append(loopback, ifc)
		}
	}

	if len(loopback) == 0 {
		t.Skip("no loopback interface found on macOS")
	}

	return []ServerOption{
		WithIncludeLoopback(true),
		WithInterfaces(loopback...),
	}
}

// skipIPv6MulticastOnDarwin skips tests that require IPv6 multicast.
// macOS 15+ drops IPv6 multicast even on loopback in headless CI.
// IPv4 multicast on loopback works; IPv6 does not.
func skipIPv6MulticastOnDarwin(t *testing.T) {
	t.Helper()

	if isDarwin {
		t.Skip("IPv6 multicast unreliable on macOS loopback (actions/runner-images#10924)")
	}
}

// fakePkt implements ipPacketConn for tests without real sockets.
type fakePkt struct {
	in    chan struct{}
	data  []byte
	src   net.Addr
	cm    *ipControlMessage
	close chan struct{}
}

var _ ipPacketConn = (*fakePkt)(nil)

func (f *fakePkt) ReadFrom(b []byte) (n int, cm *ipControlMessage, src net.Addr, err error) {
	select {
	case <-f.in:
		copy(b, f.data)

		return len(f.data), f.cm, f.src, nil
	case <-f.close:
		return 0, nil, nil, net.ErrClosed
	case <-time.After(3 * time.Second):
		return 0, nil, nil, nil
	}
}

func (f *fakePkt) WriteTo(b []byte, _ *net.Interface, _ *ipControlMessage, _ net.Addr) (int, error) {
	return len(b), nil
}

func (f *fakePkt) Close() error {
	close(f.close)

	return nil
}

func TestValidCommunication(t *testing.T) {
	lim := test.TimeOut(time.Second * 30)
	defer lim.Stop()

	report := test.CheckRoutines(t)
	defer report()

	aSock := createListener4(t)
	bSock := createListener4(t)

	darwinOpts := darwinMulticastOpts(t)

	aServer, err := NewServer(ipv4.NewPacketConn(aSock), nil,
		append([]ServerOption{
			WithLocalNames("pion-mdns-1.local", "pion-mdns-2.local"),
		}, darwinOpts...)...,
	)
	assert.NoError(t, err)

	bServer, err := NewServer(ipv4.NewPacketConn(bSock), nil, darwinOpts...)
	assert.NoError(t, err)

	_, addr, err := bServer.QueryAddr(context.TODO(), "pion-mdns-1.local")
	assert.NoError(t, err)
	assert.NotEqualf(t, localAddress, addr.String(), "unexpected local address: %v", addr)
	checkIPv4(t, addr)

	_, addr, err = bServer.QueryAddr(context.TODO(), "pion-mdns-2.local")
	assert.NoError(t, err)
	assert.NotEqualf(t, localAddress, addr.String(), "unexpected local address: %v", addr)
	checkIPv4(t, addr)

	// Verify non-loopback multicast (regression from commit 608f20b).
	// Skipped on macOS: Local Network Privacy forces loopback-only multicast in CI.
	if !isDarwin {
		for range 100 {
			_, addr, err = bServer.QueryAddr(context.TODO(), "pion-mdns-2.local")
			assert.NoError(t, err)
			assert.NotEqualf(t, localAddress, addr.String(), "unexpected local address: %v", addr)
			assert.NotEqual(t, "127.0.0.1", addr.String(), "unexpected loopback")
			checkIPv4(t, addr)
		}
	}

	assert.NoError(t, aServer.Close())
	assert.NoError(t, bServer.Close())

	assert.Empty(t, aServer.client.handler.queries, "Queries not cleaned up after aServer close")
	assert.Empty(t, bServer.client.handler.queries, "Queries not cleaned up after bServer close")
}

func TestLegacyServerAPI(t *testing.T) {
	lim := test.TimeOut(time.Second * 30)
	defer lim.Stop()

	report := test.CheckRoutines(t)
	defer report()

	// Test nil config error
	aSock := createListener4(t)
	_, err := Server(ipv4.NewPacketConn(aSock), nil, nil)
	assert.ErrorIs(t, err, errNilConfig, "expected error if nil config supplied to Server")
	assert.NoError(t, aSock.Close())

	// Test legacy API still works
	aSock = createListener4(t)
	bSock := createListener4(t)

	aCfg := &Config{
		LocalNames: []string{"pion-mdns-1.local", "pion-mdns-2.local"},
	}
	bCfg := &Config{}

	if isDarwin {
		ifaces, ifErr := net.Interfaces()
		assert.NoError(t, ifErr)

		var loopback []net.Interface
		for _, ifc := range ifaces {
			if ifc.Flags&net.FlagLoopback != 0 {
				loopback = append(loopback, ifc)
			}
		}

		aCfg.IncludeLoopback = true
		aCfg.Interfaces = loopback
		bCfg.IncludeLoopback = true
		bCfg.Interfaces = loopback
	}

	aServer, err := Server(ipv4.NewPacketConn(aSock), nil, aCfg)
	assert.NoError(t, err)

	bServer, err := Server(ipv4.NewPacketConn(bSock), nil, bCfg)
	assert.NoError(t, err)

	_, addr, err := bServer.QueryAddr(context.TODO(), "pion-mdns-1.local")
	assert.NoError(t, err)
	assert.NotEqualf(t, localAddress, addr.String(), "unexpected local address: %v", addr)
	checkIPv4(t, addr)

	assert.NoError(t, aServer.Close())
	assert.NoError(t, bServer.Close())
}

func TestValidCommunicationWithAddressConfig(t *testing.T) {
	lim := test.TimeOut(time.Second * 10)
	defer lim.Stop()

	report := test.CheckRoutines(t)
	defer report()

	aSock := createListener4(t)

	aServer, err := NewServer(ipv4.NewPacketConn(aSock), nil,
		append([]ServerOption{
			WithLocalNames("pion-mdns-1.local", "pion-mdns-2.local"),
			WithLocalAddress(net.ParseIP(localAddress)),
		}, darwinMulticastOpts(t)...)...,
	)
	assert.NoError(t, err)

	_, addr, err := aServer.QueryAddr(context.TODO(), "pion-mdns-1.local")
	assert.NoError(t, err)
	assert.Equalf(t, localAddress, addr.String(), "address mismatch: expected %s, but got %v\n", localAddress, addr)

	assert.NoError(t, aServer.Close())
	assert.Empty(t, aServer.client.handler.queries, "Queries not cleaned up after aServer close")
}

func TestValidCommunicationWithLoopbackAddressConfig(t *testing.T) {
	// loopbacks cannot join multicast groups on windows.
	if isWindows {
		t.Skip("not supported on windows")
	}

	lim := test.TimeOut(time.Second * 10)
	defer lim.Stop()

	report := test.CheckRoutines(t)
	defer report()

	aSock := createListener4(t)

	loopbackIP := net.ParseIP("127.0.0.1")

	aServer, err := NewServer(ipv4.NewPacketConn(aSock), nil,
		WithLocalNames("pion-mdns-1.local", "pion-mdns-2.local"),
		WithLocalAddress(loopbackIP),
		WithIncludeLoopback(true), // the test would fail if this was false
	)
	assert.NoError(t, err)

	_, addr, err := aServer.QueryAddr(context.TODO(), "pion-mdns-1.local")
	assert.NoError(t, err)
	assert.Equalf(t, loopbackIP.String(), addr.String(), "address mismatch: expected %s, but got %v\n", loopbackIP, addr)

	assert.NoError(t, aServer.Close())
}

func TestValidCommunicationWithLoopbackInterface(t *testing.T) {
	// loopbacks cannot join multicast groups on windows.
	if runtime.GOOS == "windows" {
		t.Skip("not supported on windows")
	}

	lim := test.TimeOut(time.Second * 10)
	defer lim.Stop()

	report := test.CheckRoutines(t)
	defer report()

	aSock := createListener4(t)

	ifaces, err := net.Interfaces()
	assert.NoError(t, err)
	ifacesToUse := make([]net.Interface, 0, len(ifaces))
	for _, ifc := range ifaces {
		if ifc.Flags&net.FlagLoopback != net.FlagLoopback {
			continue
		}
		ifcCopy := ifc
		ifacesToUse = append(ifacesToUse, ifcCopy)
	}

	// the following checks are unlikely to fail since most places where this code runs
	// will have a loopback
	if len(ifacesToUse) == 0 {
		t.Skip("expected at least one loopback interface, but got none")
	}

	aServer, err := NewServer(ipv4.NewPacketConn(aSock), nil,
		WithLocalNames("pion-mdns-1.local", "pion-mdns-2.local"),
		WithIncludeLoopback(true), // the test would fail if this was false
		WithInterfaces(ifacesToUse...),
	)
	assert.NoError(t, err)

	_, addr, err := aServer.QueryAddr(context.TODO(), "pion-mdns-1.local")
	assert.NoError(t, err)
	var found bool
	for _, iface := range ifacesToUse {
		addrs, err := iface.Addrs()
		assert.NoError(t, err)
		for _, ifaceAddr := range addrs {
			ipAddr, ok := ifaceAddr.(*net.IPNet)
			assert.Truef(t, ok, "expected *net.IPNet address for loopback but got %T", addr)
			if addr.String() == ipAddr.IP.String() {
				found = true

				break
			}
		}
		if found {
			break
		}
	}
	assert.Truef(t, found, "address mismatch: expected loopback address, but got %v\n", addr)

	assert.NoError(t, aServer.Close())
}

func TestValidCommunicationIPv6(t *testing.T) { //nolint:cyclop
	if runtime.GOARCH == "386" {
		t.Skip("IPv6 not supported on 386 for some reason")
	}
	skipIPv6MulticastOnDarwin(t)
	lim := test.TimeOut(time.Second * 10)
	defer lim.Stop()

	report := test.CheckRoutines(t)
	defer report()

	_, err := NewServer(nil, nil,
		WithLocalNames("pion-mdns-1.local", "pion-mdns-2.local"),
	)
	assert.ErrorIs(t, err, errNoPacketConn, "expected error if no PacketConn supplied to NewServer")

	aSock := createListener6(t)
	bSock := createListener6(t)

	darwinOpts := darwinMulticastOpts(t)

	aServer, err := NewServer(nil, ipv6.NewPacketConn(aSock),
		append([]ServerOption{
			WithLocalNames("pion-mdns-1.local", "pion-mdns-2.local"),
		}, darwinOpts...)...,
	)
	assert.NoError(t, err)

	bServer, err := NewServer(nil, ipv6.NewPacketConn(bSock), darwinOpts...)
	assert.NoError(t, err)

	header, addr, err := bServer.QueryAddr(context.TODO(), "pion-mdns-1.local")
	assert.NoError(t, err)
	assert.Equalf(t, dnsmessage.TypeAAAA, header.Type, "expected AAAA but got %s", header.Type)

	assert.NotEqualf(t, localAddress, addr.String(), "unexpected local address: %v", addr)
	checkIPv6(t, addr)
	if addr.Is4In6() {
		// probably within docker
		t.Logf("address %s is an IPv4-to-IPv6 mapped address even though the stack is IPv6", addr)
	} else if addr.IsLinkLocalUnicast() || addr.IsLinkLocalMulticast() {
		assert.NotEqualf(t, "", addr.Zone(), "expected link-local IPv6 to have zone but got %s", addr)
	}

	header, addr, err = bServer.QueryAddr(context.TODO(), "pion-mdns-2.local")
	assert.NoError(t, err)
	assert.Equalf(t, dnsmessage.TypeAAAA, header.Type, "expected AAAA but got %s", header.Type)

	assert.NotEqualf(t, localAddress, addr.String(), "unexpected local address: %v", addr)
	checkIPv6(t, addr)
	// addrWithOptionalZone only attaches a zone to link-local addresses, so a ULA or
	// globally routable answer legitimately has an empty zone.
	if !addr.Is4In6() && (addr.IsLinkLocalUnicast() || addr.IsLinkLocalMulticast()) {
		assert.NotEqualf(t, "", addr.Zone(), "expected link-local IPv6 to have zone but got %s", addr)
	}

	assert.NoError(t, aServer.Close())
	assert.NoError(t, bServer.Close())

	assert.Empty(t, aServer.client.handler.queries, "Queries not cleaned up after aServer close")
	assert.Empty(t, bServer.client.handler.queries, "Queries not cleaned up after bServer close")
}

func TestValidCommunicationIPv46(t *testing.T) {
	lim := test.TimeOut(time.Second * 10)
	defer lim.Stop()

	report := test.CheckRoutines(t)
	defer report()

	aSock4 := createListener4(t)
	bSock4 := createListener4(t)
	aSock6 := createListener6(t)
	bSock6 := createListener6(t)

	darwinOpts := darwinMulticastOpts(t)

	aServer, err := NewServer(ipv4.NewPacketConn(aSock4), ipv6.NewPacketConn(aSock6),
		append([]ServerOption{
			WithLocalNames("pion-mdns-1.local", "pion-mdns-2.local"),
		}, darwinOpts...)...,
	)
	assert.NoError(t, err)

	bServer, err := NewServer(ipv4.NewPacketConn(bSock4), ipv6.NewPacketConn(bSock6), darwinOpts...)
	assert.NoError(t, err)

	_, addr, err := bServer.QueryAddr(context.TODO(), "pion-mdns-1.local")
	assert.NoError(t, err)

	assert.NotEqualf(t, localAddress, addr.String(), "unexpected local address: %v", addr)

	_, addr, err = bServer.QueryAddr(context.TODO(), "pion-mdns-2.local")
	assert.NoError(t, err)
	assert.NotEqualf(t, localAddress, addr.String(), "unexpected local address: %v", addr)

	assert.NoError(t, aServer.Close())
	assert.NoError(t, bServer.Close())

	assert.Empty(t, aServer.client.handler.queries, "Queries not cleaned up after aServer close")
	assert.Empty(t, bServer.client.handler.queries, "Queries not cleaned up after bServer close")
}

func TestValidCommunicationIPv46Mixed(t *testing.T) {
	skipIPv6MulticastOnDarwin(t)
	lim := test.TimeOut(time.Second * 10)
	defer lim.Stop()

	report := test.CheckRoutines(t)
	defer report()

	aSock4 := createListener4(t)
	bSock6 := createListener6(t)

	darwinOpts := darwinMulticastOpts(t)

	// we can always send from a 6-only server to a 4-only server but not always
	// the other way around because the IPv4-only server will only listen
	// on multicast for IPv4 questions, so it will never see an IPv6 originated
	// question that contains required information to respond (the zone, if link-local).
	// Therefore, the IPv4 server will refuse answering AAAA responses over
	// unicast/multicast IPv4 if the answer is an IPv6 link-local address. This is basically
	// the majority of cases unless a LocalAddress is set on the Config.
	// aServer is IPv4-only and will perform the query
	aServer, err := NewServer(ipv4.NewPacketConn(aSock4), nil,
		append([]ServerOption{WithName("aServer")}, darwinOpts...)...,
	)
	assert.NoError(t, err)

	bOpts := []ServerOption{
		WithName("bServer"),
		WithLocalNames("pion-mdns-1.local"),
	}
	bOpts = append(bOpts, darwinOpts...)
	// for windows: provide a concrete IPv4 LocalAddress to allow answering an A record .
	// because windows cross-stack ipv4/ipv6 is unreliable.
	if isWindows {
		v4 := firstUsableIPv4Addr(t)
		bOpts = append(bOpts, WithLocalAddress(v4))
	}
	bServer, err := NewServer(nil, ipv6.NewPacketConn(bSock6), bOpts...)
	assert.NoError(t, err)

	header, addr, err := aServer.QueryAddr(context.TODO(), "pion-mdns-1.local")

	assert.NoError(t, err)
	assert.Equalf(t, dnsmessage.TypeA, header.Type, "expected A but got %s", header.Type)

	checkIPv4(t, addr)

	assert.NoError(t, aServer.Close())
	assert.NoError(t, bServer.Close())

	assert.Empty(t, aServer.client.handler.queries, "Queries not cleaned up after aServer close")
	assert.Empty(t, bServer.client.handler.queries, "Queries not cleaned up after bServer close")
}

func TestValidCommunicationIPv46MixedLocalAddress(t *testing.T) {
	skipIPv6MulticastOnDarwin(t)
	lim := test.TimeOut(time.Second * 10)
	defer lim.Stop()

	report := test.CheckRoutines(t)
	defer report()

	aSock4 := createListener4(t)
	bSock6 := createListener6(t)

	darwinOpts := darwinMulticastOpts(t)

	aServer, err := NewServer(ipv4.NewPacketConn(aSock4), nil,
		append([]ServerOption{
			WithLocalAddress(net.IPv4(1, 2, 3, 4)),
			WithLocalNames("pion-mdns-1.local"),
		}, darwinOpts...)...,
	)
	assert.NoError(t, err)

	bServer, err := NewServer(nil, ipv6.NewPacketConn(bSock6), darwinOpts...)
	assert.NoError(t, err)

	ctx, cancel := context.WithTimeout(context.Background(), 500*time.Millisecond)
	defer cancel()

	// we want ipv6 but all we can offer is an ipv4 mapped address, so it should fail until we support
	// allowing this explicitly via configuration on the aServer side
	_, _, err = bServer.QueryAddr(ctx, "pion-mdns-1.local")
	assert.ErrorIsf(t, err, errContextElapsed, "Query expired but returned unexpected error %v", err)

	assert.NoError(t, aServer.Close())
	assert.NoError(t, bServer.Close())

	assert.Empty(t, aServer.client.handler.queries, "Queries not cleaned up after aServer close")
	assert.Empty(t, bServer.client.handler.queries, "Queries not cleaned up after bServer close")
}

func TestValidCommunicationIPv66Mixed(t *testing.T) {
	skipIPv6MulticastOnDarwin(t)
	lim := test.TimeOut(time.Second * 10)
	defer lim.Stop()

	report := test.CheckRoutines(t)
	defer report()

	aSock6 := createListener6(t)
	bSock6 := createListener6(t)

	darwinOpts := darwinMulticastOpts(t)

	aServer, err := NewServer(nil, ipv6.NewPacketConn(aSock6),
		append([]ServerOption{
			WithLocalNames("pion-mdns-1.local"),
		}, darwinOpts...)...,
	)
	assert.NoError(t, err)

	bServer, err := NewServer(nil, ipv6.NewPacketConn(bSock6), darwinOpts...)
	assert.NoError(t, err)

	header, addr, err := bServer.QueryAddr(context.TODO(), "pion-mdns-1.local")
	assert.NoError(t, err)
	assert.Equalf(t, dnsmessage.TypeAAAA, header.Type, "expected AAAA but got %s", header.Type)
	assert.NotEqualf(t, localAddress, addr.String(), "unexpected local address: %v", addr)
	assert.Falsef(t, addr.Is4In6(), "expected address to not be ipv4-to-ipv6 mapped: %v", addr)
	checkIPv6(t, addr)

	assert.NoError(t, aServer.Close())
	assert.NoError(t, bServer.Close())

	assert.Empty(t, aServer.client.handler.queries, "Queries not cleaned up after aServer close")
	assert.Empty(t, bServer.client.handler.queries, "Queries not cleaned up after bServer close")
}

func TestValidCommunicationIPv66MixedLocalAddress(t *testing.T) {
	skipIPv6MulticastOnDarwin(t)
	lim := test.TimeOut(time.Second * 10)
	defer lim.Stop()

	report := test.CheckRoutines(t)
	defer report()

	aSock6 := createListener6(t)
	bSock6 := createListener6(t)

	darwinOpts := darwinMulticastOpts(t)

	aServer, err := NewServer(nil, ipv6.NewPacketConn(aSock6),
		append([]ServerOption{
			WithLocalAddress(net.IPv4(1, 2, 3, 4)),
			WithLocalNames("pion-mdns-1.local"),
		}, darwinOpts...)...,
	)
	assert.NoError(t, err)

	bServer, err := NewServer(nil, ipv6.NewPacketConn(bSock6), darwinOpts...)
	assert.NoError(t, err)

	header, addr, err := bServer.QueryAddr(context.TODO(), "pion-mdns-1.local")
	assert.NoError(t, err)
	assert.Equalf(t, dnsmessage.TypeAAAA, header.Type, "expected AAAA but got %s", header.Type)
	assert.Truef(t, addr.Is4In6(), "expected address to be ipv4-to-ipv6 mapped: %v", addr)
	// now unmap just for this check
	assert.Equalf(t, localAddress, addr.Unmap().String(), "unexpected local address: %v", addr)
	checkIPv6(t, addr)

	assert.NoError(t, aServer.Close())
	assert.NoError(t, bServer.Close())

	assert.Empty(t, aServer.client.handler.queries, "Queries not cleaned up after aServer close")
	assert.Empty(t, bServer.client.handler.queries, "Queries not cleaned up after bServer close")
}

func TestValidCommunicationIPv64Mixed(t *testing.T) {
	skipIPv6MulticastOnDarwin(t)
	lim := test.TimeOut(time.Second * 10)
	defer lim.Stop()

	report := test.CheckRoutines(t)
	defer report()

	aSock6 := createListener6(t)
	bSock4 := createListener4(t)

	darwinOpts := darwinMulticastOpts(t)

	aOpts := []ServerOption{
		WithLocalNames("pion-mdns-1.local", "pion-mdns-2.local"),
	}
	aOpts = append(aOpts, darwinOpts...)
	// for windows: provide a concrete IPv4 LocalAddress to allow answering an A record .
	// because windows cross-stack ipv4/ipv6 is unreliable.
	if isWindows {
		v4 := firstUsableIPv4Addr(t)
		aOpts = append(aOpts, WithLocalAddress(v4))
	}
	aServer, err := NewServer(nil, ipv6.NewPacketConn(aSock6), aOpts...)
	assert.NoError(t, err)

	bServer, err := NewServer(ipv4.NewPacketConn(bSock4), nil, darwinOpts...)
	assert.NoError(t, err)

	_, addr, err := bServer.QueryAddr(context.TODO(), "pion-mdns-1.local")
	assert.NoError(t, err)

	assert.NotEqualf(t, localAddress, addr.String(), "unexpected local address: %v", addr)

	header, addr, err := bServer.QueryAddr(context.TODO(), "pion-mdns-2.local")
	assert.NoError(t, err)
	assert.Equalf(t, dnsmessage.TypeA, header.Type, "expected A but got %s", header.Type)
	assert.NotEqualf(t, localAddress, addr.String(), "unexpected local address: %v", addr)

	assert.NoError(t, aServer.Close())
	assert.NoError(t, bServer.Close())

	assert.Empty(t, aServer.client.handler.queries, "Queries not cleaned up after aServer close")
	assert.Empty(t, bServer.client.handler.queries, "Queries not cleaned up after bServer close")
}

func TestLocalNameCaseInsensitivity(t *testing.T) {
	isUnicast := false
	lim := test.TimeOut(time.Second * 10)
	defer lim.Stop()

	report := test.CheckRoutines(t)
	defer report()

	fp := &fakePkt{in: make(chan struct{}, 1), close: make(chan struct{})}
	fp.src = &net.UDPAddr{IP: net.IPv4(192, 0, 2, 1), Port: 5353}

	log := logging.NewDefaultLoggerFactory().NewLogger("mdns")
	dstAddr4 := &net.UDPAddr{IP: net.IPv4(224, 0, 0, 251), Port: 5353}
	localNames := []string{"pion-mdns-1.local."}
	ifaces := map[int]netInterface{
		1: {Interface: net.Interface{Index: 1, Flags: net.FlagMulticast | net.FlagUp}, supportsV4: true},
	}

	conn := &Conn{
		name:               "test",
		log:                log,
		queryInterval:      100 * time.Millisecond,
		multicastPktConnV4: fp,
		dstAddr4:           dstAddr4,
		ifaces:             ifaces,
		cache:              newCache(time.Now),
		closed:             make(chan any),
		localNames:         localNames,
	}

	// Create client and server
	conn.client = newClient(log, "test", conn, true, false, conn.cache)
	conn.server = newServer(
		log,
		"test",
		conn,
		localNames,
		net.ParseIP("127.0.0.1"),
		ifaces,
		true,
		dstAddr4,
		&net.UDPAddr{IP: net.ParseIP("FF02::FB"), Port: 5353},
		120,
		nil, // no services
		nil, // no record type filter
	)

	started := make(chan struct{})
	go conn.start(started, 1500, &serverConfig{localAddress: net.ParseIP("127.0.0.1")})
	<-started

	name := "pion-mdns-1.local."
	answerMsg, err := conn.server.createAnswer(0, dnsmessage.Question{
		Name: dnsmessage.MustNewName(name),
		Type: dnsmessage.TypeA,
	}, netip.MustParseAddr("127.0.0.1"), isUnicast)
	assert.NoError(t, err)
	packed, err := answerMsg.Pack()
	assert.NoError(t, err)

	tests := []string{"pion-mdns-1.local", "PION-MDNS-1.local", "pion-MDNS-1.local"}
	for _, q := range tests {
		t.Run(q, func(t *testing.T) {
			ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
			defer cancel()

			go func() {
				<-time.After(50 * time.Millisecond)
				fp.data = packed
				fp.in <- struct{}{}
			}()

			_, addr, err := conn.QueryAddr(ctx, q)
			assert.NoError(t, err)
			assert.Equalf(t, "127.0.0.1", addr.String(), "address mismatch: expected %s, but got %v\n", localAddress, addr)
		})
	}

	assert.NoError(t, conn.Close())
}

func TestCommunicationCaseInsensitivity(t *testing.T) {
	isUnicast := false

	lim := test.TimeOut(time.Second * 10)
	defer lim.Stop()

	report := test.CheckRoutines(t)
	defer report()

	// Use an in-memory fake instead of real sockets to avoid OS quirks.
	fp := &fakePkt{in: make(chan struct{}, 1), close: make(chan struct{})}
	fp.src = &net.UDPAddr{IP: net.IPv4(192, 0, 2, 1), Port: 5353}

	log := logging.NewDefaultLoggerFactory().NewLogger("mdns")
	dstAddr4 := &net.UDPAddr{IP: net.IPv4(224, 0, 0, 251), Port: 5353}
	ifaces := map[int]netInterface{
		1: {
			Interface:  net.Interface{Index: 1, Flags: net.FlagMulticast | net.FlagUp},
			supportsV4: true,
		},
	}

	conn := &Conn{
		name:               "test",
		log:                log,
		queryInterval:      100 * time.Millisecond,
		multicastPktConnV4: fp,
		dstAddr4:           dstAddr4,
		ifaces:             ifaces,
		cache:              newCache(time.Now),
		closed:             make(chan any),
	}

	// Create client (no server needed for this test)
	conn.client = newClient(log, "test", conn, true, false, conn.cache)

	started := make(chan struct{})
	go conn.start(started, 1500, &serverConfig{})
	<-started

	// Create a minimal server for constructing the answer message
	testServer := &server{ttl: 120}
	name := "pion-MDNS-1.local."
	answerMsg, err := testServer.createAnswer(0, dnsmessage.Question{
		Name: dnsmessage.MustNewName(name),
		Type: dnsmessage.TypeA,
	}, netip.MustParseAddr(localAddress), isUnicast)
	assert.NoError(t, err)
	packed, err := answerMsg.Pack()
	assert.NoError(t, err)

	tests := []string{"pion-mdns-1.local", "pion-MDNS-1.local"}
	for _, testName := range tests {
		t.Run(testName, func(t *testing.T) {
			ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
			defer cancel()

			ready := make(chan struct{})
			go func() {
				<-time.After(50 * time.Millisecond)
				fp.data = packed
				fp.in <- struct{}{}
				close(ready)
			}()

			_, addr, err := conn.QueryAddr(ctx, testName)
			assert.NoError(t, err)
			assert.Equalf(t, localAddress, addr.String(), "unexpected local address: %v", addr)
			<-ready
		})
	}

	assert.NoError(t, conn.Close())
}

func TestMultipleClose(t *testing.T) {
	lim := test.TimeOut(time.Second * 10)
	defer lim.Stop()

	report := test.CheckRoutines(t)
	defer report()

	aSock := createListener4(t)

	server, err := NewServer(ipv4.NewPacketConn(aSock), nil)
	assert.NoError(t, err)

	assert.NoError(t, server.Close())
	assert.NoError(t, server.Close())

	assert.Empty(t, server.client.handler.queries, "Queries not cleaned up after server close")
}

func TestQueryRespectTimeout(t *testing.T) {
	lim := test.TimeOut(time.Second * 10)
	defer lim.Stop()

	report := test.CheckRoutines(t)
	defer report()

	aSock := createListener4(t)

	server, err := NewServer(ipv4.NewPacketConn(aSock), nil)
	assert.NoError(t, err)

	ctx, cancel := context.WithTimeout(context.Background(), 500*time.Millisecond)
	defer cancel()

	_, _, err = server.QueryAddr(ctx, "invalid-host")
	assert.ErrorIsf(t, err, errContextElapsed, "Query expired but returned unexpected error %v", err)

	assert.NoError(t, server.Close())

	assert.Empty(t, server.client.handler.queries, "Queries not cleaned up after server close")
}

func TestQueryRespectClose(t *testing.T) {
	lim := test.TimeOut(time.Second * 10)
	defer lim.Stop()

	report := test.CheckRoutines(t)
	defer report()

	aSock := createListener4(t)

	server, err := NewServer(ipv4.NewPacketConn(aSock), nil)
	assert.NoError(t, err)

	go func() {
		time.Sleep(3 * time.Second)
		assert.NoError(t, server.Close())
	}()

	_, _, err = server.QueryAddr(context.TODO(), "invalid-host")
	assert.ErrorIsf(t, err, errConnectionClosed, "Query on closed server but returned unexpected error %v", err)

	_, _, err = server.QueryAddr(context.TODO(), "invalid-host")
	assert.ErrorIsf(t, err, errConnectionClosed, "Query on closed server but returned unexpected error %v", err)

	assert.Empty(t, server.client.handler.queries, "Queries not cleaned up after server close")
}

func testResourceParsing(t *testing.T, echoQuery bool) { //nolint:thelper
	// Create a minimal server for testing createAnswer
	testServer := &server{ttl: 120}

	lookForIP := func(t *testing.T, msg dnsmessage.Message, expectedIP []byte) {
		t.Helper()
		actualAddr, err := addrFromAnswer(msg.Answers[0])
		if err != nil {
			assert.NoError(t, err)
		}

		if echoQuery {
			if len(msg.Questions) == 0 {
				assert.Fail(t, "Echoed query not included in answer")
			}
		} else {
			if len(msg.Questions) > 0 {
				assert.Fail(t, "Echoed query erroneously included in answer")
			}
		}

		assert.Equalf(
			t,
			expectedIP,
			actualAddr.AsSlice(),
			"Expected(%v) and Actual(%v) IP don't match",
			expectedIP,
			actualAddr.AsSlice(),
		)
	}

	name := "test-server."
	t.Run("A Record", func(t *testing.T) {
		answer, err := testServer.createAnswer(1, dnsmessage.Question{
			Name: dnsmessage.MustNewName(name),
			Type: dnsmessage.TypeA,
		}, mustAddr(t, net.IP{127, 0, 0, 1}), echoQuery)
		if err != nil {
			assert.NoError(t, err)
		}
		lookForIP(t, answer, []byte{127, 0, 0, 1})
	})

	t.Run("AAAA Record", func(t *testing.T) {
		answer, err := testServer.createAnswer(1, dnsmessage.Question{
			Name: dnsmessage.MustNewName(name),
			Type: dnsmessage.TypeAAAA,
		}, netip.MustParseAddr("::1"), echoQuery)
		if err != nil {
			assert.NoError(t, err)
		}
		lookForIP(t, answer, []byte{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1})
	})
}

func TestResourceParsingWithEchoedQuery(t *testing.T) {
	testResourceParsing(t, true)
}

func TestResourceParsingWithoutEchoedQuery(t *testing.T) {
	testResourceParsing(t, false)
}

func mustAddr(t *testing.T, ip net.IP) netip.Addr {
	t.Helper()
	addr, ok := netip.AddrFromSlice(ip)
	assert.True(t, ok)

	return addr
}

// End-to-end tests: client Browse/EnumerateServiceTypes against server with registered services.

func TestBrowseEndToEnd(t *testing.T) {
	lim := test.TimeOut(time.Second * 30)
	defer lim.Stop()

	report := test.CheckRoutines(t)
	defer report()

	aSock := createListener4(t)
	bSock := createListener4(t)

	darwinOpts := darwinMulticastOpts(t)

	// Server advertises a service.
	aServer, err := NewServer(ipv4.NewPacketConn(aSock), nil,
		append([]ServerOption{
			WithLocalNames("myhost.local"),
			WithService(ServiceInstance{
				Instance: "My Web Server",
				Service:  "_http._tcp",
				Port:     8080,
				Text:     []TXTEntry{NewTXTString("path", "/")},
			}),
		}, darwinOpts...)...,
	)
	assert.NoError(t, err)

	// Client browses for the service.
	bServer, err := NewServer(ipv4.NewPacketConn(bSock), nil, darwinOpts...)
	assert.NoError(t, err)

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	found := make(chan ServiceEvent, 1)
	bServer.OnServiceDiscovered(func(evt ServiceEvent) {
		select {
		case found <- evt:
		default:
		}
	})

	err = bServer.Browse(ctx, "_http._tcp")
	assert.NoError(t, err)

	// Should discover the service.
	select {
	case evt := <-found:
		assert.Equal(t, "My Web Server", evt.Instance.Instance)
		assert.Equal(t, "_http._tcp", evt.Instance.Service)
		assert.Equal(t, "local", evt.Instance.Domain)
		assert.Equal(t, uint16(8080), evt.Instance.Port)
		assert.NotEqual(t, netip.Addr{}, evt.Addr, "expected resolved address")
		assert.True(t, evt.Addr.IsValid(), "expected valid address")
		assert.Len(t, evt.Instance.Text, 1)
		assert.Equal(t, "path", evt.Instance.Text[0].Key)
		assert.Equal(t, []byte("/"), evt.Instance.Text[0].Value)
	case <-ctx.Done():
		assert.Fail(t, "timed out waiting for browse result")
	}

	cancel()
	assert.NoError(t, aServer.Close())
	assert.NoError(t, bServer.Close())
}

func TestBrowseMultipleServicesEndToEnd(t *testing.T) {
	lim := test.TimeOut(time.Second * 30)
	defer lim.Stop()

	report := test.CheckRoutines(t)
	defer report()

	aSock := createListener4(t)
	bSock := createListener4(t)

	darwinOpts := darwinMulticastOpts(t)

	// Server advertises two services of the same type.
	aServer, err := NewServer(ipv4.NewPacketConn(aSock), nil,
		append([]ServerOption{
			WithLocalNames("myhost.local"),
			WithService(ServiceInstance{
				Instance: "First Service",
				Service:  "_http._tcp",
				Port:     8080,
			}),
			WithService(ServiceInstance{
				Instance: "Second Service",
				Service:  "_http._tcp",
				Port:     9090,
			}),
		}, darwinOpts...)...,
	)
	assert.NoError(t, err)

	bServer, err := NewServer(ipv4.NewPacketConn(bSock), nil, darwinOpts...)
	assert.NoError(t, err)

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	var mu sync.Mutex
	seen := make(map[string]uint16)
	done := make(chan struct{})
	bServer.OnServiceDiscovered(func(evt ServiceEvent) {
		mu.Lock()
		defer mu.Unlock()
		seen[evt.Instance.Instance] = evt.Instance.Port
		// Check for the specific instances: real mDNS traffic on the test
		// machine's network may add unrelated entries.
		if _, ok := seen["First Service"]; !ok {
			return
		}
		if _, ok := seen["Second Service"]; !ok {
			return
		}
		select {
		case <-done:
		default:
			close(done)
		}
	})

	err = bServer.Browse(ctx, "_http._tcp")
	assert.NoError(t, err)

	select {
	case <-done:
	case <-ctx.Done():
		assert.Fail(t, "timed out waiting for browse results")
	}

	mu.Lock()
	assert.Equal(t, uint16(8080), seen["First Service"])
	assert.Equal(t, uint16(9090), seen["Second Service"])
	mu.Unlock()

	cancel()
	assert.NoError(t, aServer.Close())
	assert.NoError(t, bServer.Close())
}

// TestBrowseCacheRefreshKeepsRecordAlive verifies the RFC 6762 §5.2 closed
// loop: a browsed record with a short TTL is re-queried before expiry and
// the answer keeps the cache entry alive past the original TTL.
func TestBrowseCacheRefreshKeepsRecordAlive(t *testing.T) {
	lim := test.TimeOut(time.Second * 30)
	defer lim.Stop()

	report := test.CheckRoutines(t)
	defer report()

	aSock := createListener4(t)
	bSock := createListener4(t)

	darwinOpts := darwinMulticastOpts(t)

	// Advertise with a 2s TTL so the refresh path triggers quickly.
	aServer, err := NewServer(ipv4.NewPacketConn(aSock), nil,
		append([]ServerOption{
			WithLocalNames("myhost.local"),
			WithResponseTTL(2),
			WithService(ServiceInstance{
				Instance: "Refresh Me",
				Service:  "_http._tcp",
				Port:     8080,
			}),
		}, darwinOpts...)...,
	)
	assert.NoError(t, err)

	bServer, err := NewServer(ipv4.NewPacketConn(bSock), nil,
		append([]ServerOption{
			WithRefreshInterval(100 * time.Millisecond),
		}, darwinOpts...)...,
	)
	assert.NoError(t, err)

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	discovered := make(chan struct{})
	bServer.OnServiceDiscovered(func(evt ServiceEvent) {
		if evt.Instance.Instance != "Refresh Me" {
			return
		}
		select {
		case <-discovered:
		default:
			close(discovered)
		}
	})

	err = bServer.Browse(ctx, "_http._tcp")
	assert.NoError(t, err)

	select {
	case <-discovered:
	case <-ctx.Done():
		assert.Fail(t, "timed out waiting for browse result")
	}

	// Wait past the original 2s TTL. Refresh queries at 80%+ of TTL must
	// have re-fetched the record, keeping it alive in the cache.
	time.Sleep(2500 * time.Millisecond)

	results := bServer.cache.lookup("_http._tcp.local.", dnsmessage.TypePTR, dnsmessage.ClassINET)
	assert.NotEmpty(t, results, "PTR record should be kept alive by cache refresh")

	cancel()
	assert.NoError(t, aServer.Close())
	assert.NoError(t, bServer.Close())
}

func TestBrowseInvalidServiceName(t *testing.T) {
	lim := test.TimeOut(time.Second * 10)
	defer lim.Stop()

	report := test.CheckRoutines(t)
	defer report()

	aSock := createListener4(t)
	aServer, err := NewServer(ipv4.NewPacketConn(aSock), nil)
	assert.NoError(t, err)

	err = aServer.Browse(context.Background(), "invalid")
	assert.ErrorIs(t, err, errInvalidServiceName)

	assert.NoError(t, aServer.Close())
}

func TestBrowseContextCancellation(t *testing.T) {
	lim := test.TimeOut(time.Second * 10)
	defer lim.Stop()

	report := test.CheckRoutines(t)
	defer report()

	aSock := createListener4(t)
	aServer, err := NewServer(ipv4.NewPacketConn(aSock), nil)
	assert.NoError(t, err)

	ctx, cancel := context.WithCancel(context.Background())

	err = aServer.Browse(ctx, "_http._tcp")
	assert.NoError(t, err)

	// Cancel immediately — the browse goroutine should exit cleanly.
	cancel()

	// Give the goroutine a moment to clean up.
	time.Sleep(100 * time.Millisecond)

	assert.NoError(t, aServer.Close())
}

func TestEnumerateServiceTypesEndToEnd(t *testing.T) {
	lim := test.TimeOut(time.Second * 30)
	defer lim.Stop()

	report := test.CheckRoutines(t)
	defer report()

	aSock := createListener4(t)
	bSock := createListener4(t)

	darwinOpts := darwinMulticastOpts(t)

	// Server advertises services of two different types.
	aServer, err := NewServer(ipv4.NewPacketConn(aSock), nil,
		append([]ServerOption{
			WithLocalNames("myhost.local"),
			WithService(ServiceInstance{
				Instance: "My Web",
				Service:  "_http._tcp",
				Port:     8080,
			}),
			WithService(ServiceInstance{
				Instance: "My Printer",
				Service:  "_ipp._tcp",
				Port:     631,
			}),
		}, darwinOpts...)...,
	)
	assert.NoError(t, err)

	bServer, err := NewServer(ipv4.NewPacketConn(bSock), nil, darwinOpts...)
	assert.NoError(t, err)

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	var mu sync.Mutex
	seen := make(map[string]bool)
	done := make(chan struct{})
	bServer.OnServiceTypeDiscovered(func(svcType string) {
		mu.Lock()
		defer mu.Unlock()
		seen[svcType] = true
		// Check for the specific types: real mDNS traffic on the test
		// machine's network may add unrelated entries.
		if !seen["_http._tcp"] || !seen["_ipp._tcp"] {
			return
		}
		select {
		case <-done:
		default:
			close(done)
		}
	})

	err = bServer.EnumerateServiceTypes(ctx)
	assert.NoError(t, err)

	select {
	case <-done:
	case <-ctx.Done():
		assert.Fail(t, "timed out waiting for service type enumeration results")
	}

	mu.Lock()
	assert.True(t, seen["_http._tcp"])
	assert.True(t, seen["_ipp._tcp"])
	mu.Unlock()

	cancel()
	assert.NoError(t, aServer.Close())
	assert.NoError(t, bServer.Close())
}

func TestQueryAddrAndBrowseCoexist(t *testing.T) {
	lim := test.TimeOut(time.Second * 30)
	defer lim.Stop()

	report := test.CheckRoutines(t)
	defer report()

	aSock := createListener4(t)
	bSock := createListener4(t)

	darwinOpts := darwinMulticastOpts(t)

	// Server advertises both a local name and a service.
	aServer, err := NewServer(ipv4.NewPacketConn(aSock), nil,
		append([]ServerOption{
			WithLocalNames("pion-mdns-coexist.local"),
			WithService(ServiceInstance{
				Instance: "Coexist Service",
				Service:  "_http._tcp",
				Port:     8080,
			}),
		}, darwinOpts...)...,
	)
	assert.NoError(t, err)

	bServer, err := NewServer(ipv4.NewPacketConn(bSock), nil, darwinOpts...)
	assert.NoError(t, err)

	// Both QueryAddr and Browse should work simultaneously.
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	// Start browsing.
	found := make(chan ServiceEvent, 1)
	bServer.OnServiceDiscovered(func(evt ServiceEvent) {
		select {
		case found <- evt:
		default:
		}
	})

	err = bServer.Browse(ctx, "_http._tcp")
	assert.NoError(t, err)

	// Also query for an address.
	_, addr, err := bServer.QueryAddr(ctx, "pion-mdns-coexist.local")
	assert.NoError(t, err)
	assert.True(t, addr.IsValid(), "expected valid address from QueryAddr")
	checkIPv4(t, addr)

	// Browse should also discover the service.
	select {
	case evt := <-found:
		assert.Equal(t, "Coexist Service", evt.Instance.Instance)
		assert.Equal(t, uint16(8080), evt.Instance.Port)
	case <-ctx.Done():
		assert.Fail(t, "timed out waiting for browse result")
	}

	cancel()
	assert.NoError(t, aServer.Close())
	assert.NoError(t, bServer.Close())
}

func TestDynamicRegisterAndBrowse(t *testing.T) {
	lim := test.TimeOut(time.Second * 30)
	defer lim.Stop()

	report := test.CheckRoutines(t)
	defer report()

	aSock := createListener4(t)
	bSock := createListener4(t)

	darwinOpts := darwinMulticastOpts(t)

	// Server starts with no services.
	aServer, err := NewServer(ipv4.NewPacketConn(aSock), nil,
		append([]ServerOption{
			WithLocalNames("dynamichost.local"),
		}, darwinOpts...)...,
	)
	assert.NoError(t, err)

	bServer, err := NewServer(ipv4.NewPacketConn(bSock), nil, darwinOpts...)
	assert.NoError(t, err)

	// Dynamically register a service after construction.
	err = aServer.Register(ServiceInstance{
		Instance: "Dynamic Service",
		Service:  "_http._tcp",
		Port:     7070,
	})
	assert.NoError(t, err)

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	found := make(chan ServiceEvent, 1)
	bServer.OnServiceDiscovered(func(evt ServiceEvent) {
		select {
		case found <- evt:
		default:
		}
	})

	err = bServer.Browse(ctx, "_http._tcp")
	assert.NoError(t, err)

	select {
	case evt := <-found:
		assert.Equal(t, "Dynamic Service", evt.Instance.Instance)
		assert.Equal(t, uint16(7070), evt.Instance.Port)
	case <-ctx.Done():
		assert.Fail(t, "timed out waiting for dynamically registered service")
	}

	cancel()
	assert.NoError(t, aServer.Close())
	assert.NoError(t, bServer.Close())
}

func TestIPToBytes(t *testing.T) { //nolint:cyclop
	expectedIP := []byte{127, 0, 0, 1}
	actualAddr4, err := ipv4ToBytes(netip.MustParseAddr("127.0.0.1"))
	assert.NoError(t, err)
	assert.Equalf(t, expectedIP, actualAddr4[:], "Expected(%v) and Actual(%v) IP don't match", expectedIP, actualAddr4)

	expectedIP = []byte{0, 0, 0, 1}
	actualAddr4, err = ipv4ToBytes(netip.MustParseAddr("0.0.0.1"))
	assert.NoError(t, err)
	assert.Equalf(t, expectedIP, actualAddr4[:], "Expected(%v) and Actual(%v) IP don't match", expectedIP, actualAddr4)

	expectedIP = []byte{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1}
	actualAddr6, err := ipv6ToBytes(netip.MustParseAddr("::1"))
	assert.NoError(t, err)
	assert.Equalf(t, expectedIP, actualAddr6[:], "Expected(%v) and Actual(%v) IP don't match", expectedIP, actualAddr6)

	_, err = ipv4ToBytes(netip.MustParseAddr("::1"))
	assert.Error(t, err, "::1 should not be output to IPv4 bytes")

	expectedIP = []byte{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 127, 0, 0, 1}
	addr, ok := netip.AddrFromSlice(net.ParseIP("127.0.0.1"))
	assert.True(t, ok, "expected to be able to convert IP to netip.Addr")
	actualAddr6, err = ipv6ToBytes(addr)
	assert.NoError(t, err)
	assert.Equalf(t, expectedIP, actualAddr6[:], "Expected(%v) and Actual(%v) IP don't match", expectedIP, actualAddr6)
}
