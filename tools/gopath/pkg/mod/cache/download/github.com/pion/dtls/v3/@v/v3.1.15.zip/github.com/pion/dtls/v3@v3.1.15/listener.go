// SPDX-FileCopyrightText: 2026 The Pion community <https://pion.ly>
// SPDX-License-Identifier: MIT

package dtls

import (
	"net"

	"github.com/pion/dtls/v3/internal/net/udp"
	dtlsnet "github.com/pion/dtls/v3/pkg/net"
	"github.com/pion/dtls/v3/pkg/protocol"
	"github.com/pion/dtls/v3/pkg/protocol/recordlayer"
)

// Listen creates a DTLS listener.
//
// Deprecated: Use ListenWithOptions instead.
func Listen(network string, laddr *net.UDPAddr, config *Config) (net.Listener, error) {
	if err := validateConfig(config); err != nil {
		return nil, err
	}

	lc := udp.ListenConfig{
		AcceptFilter: func(packet []byte) bool {
			pkts, err := recordlayer.UnpackDatagram(packet)
			if err != nil || len(pkts) < 1 {
				return false
			}
			h := &recordlayer.Header{}
			if err := h.Unmarshal(pkts[0]); err != nil {
				return false
			}

			return h.ContentType == protocol.ContentTypeHandshake
		},
		ListenConfig: config.listenConfig,
	}
	// If connection ID support is enabled, then they must be supported in
	// routing.
	if config.ConnectionIDGenerator != nil {
		lc.DatagramRouter = cidDatagramRouter(len(config.ConnectionIDGenerator()))
		lc.ConnectionIdentifier = cidConnIdentifier()
	}
	parent, err := lc.Listen(network, laddr)
	if err != nil {
		return nil, err
	}

	return &listener{
		config: config,
		parent: parent,
	}, nil
}

// ListenWithOptions creates a DTLS listener.
func ListenWithOptions(network string, laddr *net.UDPAddr, opts ...ServerOption) (net.Listener, error) {
	config, err := buildServerConfig(opts...)
	if err != nil {
		return nil, err
	}

	return Listen(network, laddr, config)
}

// NewListener creates a DTLS listener which accepts connections from an inner Listener.
//
// Deprecated: Use NewListenerWithOptions instead.
func NewListener(inner dtlsnet.PacketListener, config *Config) (net.Listener, error) {
	if err := validateConfig(config); err != nil {
		return nil, err
	}

	return &listener{
		config: config,
		parent: inner,
	}, nil
}

// NewListenerWithOptions creates a DTLS listener which accepts connections from an inner Listener.
func NewListenerWithOptions(inner dtlsnet.PacketListener, opts ...ServerOption) (net.Listener, error) {
	config, err := buildServerConfig(opts...)
	if err != nil {
		return nil, err
	}

	return NewListener(inner, config)
}

// listener represents a DTLS listener.
type listener struct {
	config *Config
	parent dtlsnet.PacketListener
}

// Accept waits for and returns the next connection to the listener.
// You have to either close or read on all connection that are created.
func (l *listener) Accept() (net.Conn, error) {
	c, raddr, err := l.parent.Accept()
	if err != nil {
		return nil, err
	}

	conn, err := serverWithConfig(c, raddr, l.config)
	if err != nil {
		_ = c.Close()

		return nil, err
	}

	return conn, nil
}

// Close closes the listener.
// Any blocked Accept operations will be unblocked and return errors.
// Already Accepted connections are not closed.
func (l *listener) Close() error {
	return l.parent.Close()
}

// Addr returns the listener's network address.
func (l *listener) Addr() net.Addr {
	return l.parent.Addr()
}
