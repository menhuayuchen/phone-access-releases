module github.com/pion/webrtc/v4

go 1.24.0

require (
	github.com/pion/datachannel v1.6.3
	github.com/pion/dtls/v3 v3.1.15
	github.com/pion/ice/v4 v4.4.8
	github.com/pion/interceptor v0.1.51
	github.com/pion/logging v0.2.4
	github.com/pion/randutil v0.1.0
	github.com/pion/rtcp v1.2.20
	github.com/pion/rtp v1.10.6
	github.com/pion/sctp v1.12.0
	github.com/pion/sdp/v3 v3.0.20
	github.com/pion/srtp/v3 v3.1.3
	github.com/pion/stun/v4 v4.0.1
	github.com/pion/transport/v5 v5.1.4
	github.com/pion/turn/v5 v5.1.3
	github.com/sclevine/agouti v3.0.0+incompatible
	github.com/stretchr/testify v1.12.1
	golang.org/x/net v0.50.0
)

require (
	github.com/google/uuid v1.6.0 // indirect
	github.com/onsi/ginkgo v1.16.5 // indirect
	github.com/onsi/gomega v1.17.0 // indirect
	github.com/pion/mdns/v2 v2.2.2 // indirect
	github.com/wlynxg/anet v0.0.5 // indirect
	go.yaml.in/yaml/v3 v3.0.5 // indirect
	golang.org/x/crypto v0.48.0 // indirect
	golang.org/x/sys v0.41.0 // indirect
	golang.org/x/time v0.14.0 // indirect
)
