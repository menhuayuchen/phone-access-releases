// SPDX-FileCopyrightText: 2026 The Pion community <https://pion.ly>
// SPDX-License-Identifier: MIT

// Package client implements the API for a TURN client
package client

import (
	"context"
	"net"

	"github.com/pion/stun/v4"
)

// Client is an interface for the public turn.Client in order to break cyclic dependencies.
type Client interface {
	WriteTo(data []byte, to net.Addr) (int, error)
	PerformTransactionWithContext(msg *stun.Message, to net.Addr, dontWait bool, ctx context.Context) (TransactionResult, error)
	OnDeallocated(relayedAddr net.Addr)
}
