module github.com/pion/datachannel

require (
	github.com/pion/logging v0.2.4
	github.com/pion/sctp v1.11.2
	github.com/pion/transport/v5 v5.0.0
	github.com/stretchr/testify v1.12.1
)

require (
	github.com/pion/randutil v0.1.0 // indirect
	go.yaml.in/yaml/v3 v3.0.5 // indirect
)

go 1.24.0
