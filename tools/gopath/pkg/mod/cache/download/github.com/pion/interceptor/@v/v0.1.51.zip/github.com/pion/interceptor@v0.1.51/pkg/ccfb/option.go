// SPDX-FileCopyrightText: 2026 The Pion community <https://pion.ly>
// SPDX-License-Identifier: MIT

package ccfb

import (
	"time"

	"github.com/pion/logging"
)

// An Option is a function that can be used to configure a SenderInterceptor.
type Option func(*SenderInterceptor) error

// SenderTicker sets an alternative for time.Ticker.
func SenderTicker(f TickerFactory) Option {
	return func(i *SenderInterceptor) error {
		i.newTicker = f

		return nil
	}
}

// SenderNow sets an alternative for the time.Now function.
func SenderNow(f func() time.Time) Option {
	return func(i *SenderInterceptor) error {
		i.now = f

		return nil
	}
}

// SendInterval sets the feedback send interval for the interceptor.
func SendInterval(interval time.Duration) Option {
	return func(s *SenderInterceptor) error {
		s.interval = interval

		return nil
	}
}

// WithLoggerFactory sets the logger factory for the interceptor.
func WithLoggerFactory(loggerFactory logging.LoggerFactory) Option {
	return func(i *SenderInterceptor) error {
		i.loggerFactory = loggerFactory

		return nil
	}
}
