module github.com/pion/interceptor

go 1.24.0

require (
	github.com/pion/logging v0.2.4
	github.com/pion/rtcp v1.2.20
	github.com/pion/rtp v1.10.6
	github.com/pion/transport/v5 v5.1.1
	github.com/stretchr/testify v1.12.1
	golang.org/x/time v0.14.0
)

require (
	github.com/pion/randutil v0.1.0 // indirect
	go.yaml.in/yaml/v3 v3.0.5 // indirect
)
