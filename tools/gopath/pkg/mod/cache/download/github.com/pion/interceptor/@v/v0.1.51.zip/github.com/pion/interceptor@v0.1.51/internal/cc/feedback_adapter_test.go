// SPDX-FileCopyrightText: 2026 The Pion community <https://pion.ly>
// SPDX-License-Identifier: MIT

package cc

import (
	"fmt"
	"math"
	"testing"
	"time"

	"github.com/pion/interceptor"
	"github.com/pion/rtcp"
	"github.com/pion/rtp"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

const hdrExtID = uint8(1)

func TestUnpackRunLengthChunk(t *testing.T) {
	attributes := make(interceptor.Attributes)
	attributes.Set(TwccExtensionAttributesKey, hdrExtID)

	cases := []struct {
		sentTLCC []uint16
		chunk    rtcp.RunLengthChunk
		deltas   []*rtcp.RecvDelta
		start    uint16
		// expect:
		acks    []Acknowledgment
		refTime time.Time
		n       int
	}{
		{
			sentTLCC: []uint16{},
			chunk:    rtcp.RunLengthChunk{},
			deltas:   []*rtcp.RecvDelta{},
			start:    0,
			acks:     []Acknowledgment{},
			refTime:  time.Time{},
			n:        0,
		},
		{
			sentTLCC: []uint16{0, 1, 2, 3, 4, 5},
			chunk: rtcp.RunLengthChunk{
				PacketStatusChunk:  nil,
				Type:               0,
				PacketStatusSymbol: rtcp.TypeTCCPacketReceivedSmallDelta,
				RunLength:          6,
			},
			deltas: []*rtcp.RecvDelta{
				{Type: rtcp.TypeTCCPacketReceivedSmallDelta, Delta: 0},
				{Type: rtcp.TypeTCCPacketReceivedSmallDelta, Delta: 0},
				{Type: rtcp.TypeTCCPacketReceivedSmallDelta, Delta: 0},
				{Type: rtcp.TypeTCCPacketReceivedSmallDelta, Delta: 0},
				{Type: rtcp.TypeTCCPacketReceivedSmallDelta, Delta: 0},
				{Type: rtcp.TypeTCCPacketReceivedSmallDelta, Delta: 0},
			},
			start: 0,
			//nolint:dupl
			acks: []Acknowledgment{
				{
					SequenceNumber: 0,
					Size:           0,
					Departure:      time.Time{},
					Arrival:        time.Time{},
				},
				{
					SequenceNumber: 1,
					Size:           0,
					Departure:      time.Time{},
					Arrival:        time.Time{},
				},
				{
					SequenceNumber: 2,
					Size:           0,
					Departure:      time.Time{},
					Arrival:        time.Time{},
				},
				{
					SequenceNumber: 3,
					Size:           0,
					Departure:      time.Time{},
					Arrival:        time.Time{},
				},
				{
					SequenceNumber: 4,
					Size:           0,
					Departure:      time.Time{},
					Arrival:        time.Time{},
				},
				{
					SequenceNumber: 5,
					Size:           0,
					Departure:      time.Time{},
					Arrival:        time.Time{},
				},
			},
			n:       6,
			refTime: time.Time{},
		},
		{
			sentTLCC: []uint16{65534, 65535, 0, 1, 2, 3},
			chunk: rtcp.RunLengthChunk{
				PacketStatusChunk:  nil,
				Type:               0,
				PacketStatusSymbol: rtcp.TypeTCCPacketReceivedSmallDelta,
				RunLength:          6,
			},
			deltas: []*rtcp.RecvDelta{
				{Type: rtcp.TypeTCCPacketReceivedSmallDelta, Delta: 250},
				{Type: rtcp.TypeTCCPacketReceivedSmallDelta, Delta: 250},
				{Type: rtcp.TypeTCCPacketReceivedSmallDelta, Delta: 250},
				{Type: rtcp.TypeTCCPacketReceivedSmallDelta, Delta: 250},
				{Type: rtcp.TypeTCCPacketReceivedSmallDelta, Delta: 250},
				{Type: rtcp.TypeTCCPacketReceivedSmallDelta, Delta: 250},
			},
			start: 65534,
			acks: []Acknowledgment{
				{
					SequenceNumber: 65534,
					Size:           0,
					Departure:      time.Time{},
					Arrival:        time.Time{}.Add(250 * time.Microsecond),
				},
				{
					SequenceNumber: 65535,
					Size:           0,
					Departure:      time.Time{},
					Arrival:        time.Time{}.Add(500 * time.Microsecond),
				},
				{
					SequenceNumber: 0,
					Size:           0,
					Departure:      time.Time{},
					Arrival:        time.Time{}.Add(750 * time.Microsecond),
				},
				{
					SequenceNumber: 1,
					Size:           0,
					Departure:      time.Time{},
					Arrival:        time.Time{}.Add(1000 * time.Microsecond),
				},
				{
					SequenceNumber: 2,
					Size:           0,
					Departure:      time.Time{},
					Arrival:        time.Time{}.Add(1250 * time.Microsecond),
				},
				{
					SequenceNumber: 3,
					Size:           0,
					Departure:      time.Time{},
					Arrival:        time.Time{}.Add(1500 * time.Microsecond),
				},
			},
			n:       6,
			refTime: time.Time{}.Add(1500 * time.Microsecond),
		},
		{
			sentTLCC: []uint16{65534, 65535, 0, 1, 2, 3},
			chunk: rtcp.RunLengthChunk{
				PacketStatusChunk:  nil,
				Type:               0,
				PacketStatusSymbol: rtcp.TypeTCCPacketNotReceived,
				RunLength:          6,
			},
			deltas: []*rtcp.RecvDelta{},
			start:  65534,
			//nolint:dupl
			acks: []Acknowledgment{
				{
					SequenceNumber: 65534,
					Size:           0,
					Departure:      time.Time{},
					Arrival:        time.Time{},
				},
				{
					SequenceNumber: 65535,
					Size:           0,
					Departure:      time.Time{},
					Arrival:        time.Time{},
				},
				{
					SequenceNumber: 0,
					Size:           0,
					Departure:      time.Time{},
					Arrival:        time.Time{},
				},
				{
					SequenceNumber: 1,
					Size:           0,
					Departure:      time.Time{},
					Arrival:        time.Time{},
				},
				{
					SequenceNumber: 2,
					Size:           0,
					Departure:      time.Time{},
					Arrival:        time.Time{},
				},
				{
					SequenceNumber: 3,
					Size:           0,
					Departure:      time.Time{},
					Arrival:        time.Time{},
				},
			},
			n:       0,
			refTime: time.Time{},
		},
	}

	//nolint:dupl
	for i, tc := range cases {
		t.Run(fmt.Sprintf("%v", i), func(t *testing.T) {
			fa := NewFeedbackAdapter()

			headers := []*rtp.Header{}
			for i, nr := range tc.sentTLCC {
				headers = append(headers, &getPacketWithTransportCCExt(t, nr).Header)
				tc.acks[i].Size += headers[i].MarshalSize()
			}
			for _, h := range headers {
				assert.NoError(t, fa.OnSent(time.Time{}, h, 0, attributes))
			}

			n, refTime, _, acks, err := fa.unpackRunLengthChunk(tc.start, time.Time{}, &tc.chunk, tc.deltas, math.MaxUint16)
			assert.NoError(t, err)
			assert.Len(t, acks, len(tc.acks))
			assert.Equal(t, tc.n, n)
			assert.Equal(t, tc.refTime, refTime)

			for i, a := range acks {
				assert.Equal(t, tc.sentTLCC[i], a.SequenceNumber)
			}
			assert.Equal(t, tc.acks, acks)
		})
	}
}

func TestUnpackStatusVectorChunk(t *testing.T) {
	attributes := make(interceptor.Attributes)
	attributes.Set(TwccExtensionAttributesKey, hdrExtID)

	cases := []struct {
		sentTLCC []uint16
		chunk    rtcp.StatusVectorChunk
		deltas   []*rtcp.RecvDelta
		start    uint16
		// expect:
		acks    []Acknowledgment
		n       int
		refTime time.Time
	}{
		{
			sentTLCC: []uint16{},
			chunk:    rtcp.StatusVectorChunk{},
			deltas:   []*rtcp.RecvDelta{},
			start:    0,
			acks:     []Acknowledgment{},
			n:        0,
			refTime:  time.Time{},
		},
		{
			sentTLCC: []uint16{0, 1, 2, 3, 4, 5},
			chunk: rtcp.StatusVectorChunk{
				PacketStatusChunk: nil,
				Type:              0,
				SymbolSize:        rtcp.TypeTCCSymbolSizeTwoBit,
				SymbolList: []uint16{
					rtcp.TypeTCCPacketReceivedSmallDelta,
					rtcp.TypeTCCPacketReceivedSmallDelta,
					rtcp.TypeTCCPacketReceivedSmallDelta,
					rtcp.TypeTCCPacketReceivedSmallDelta,
					rtcp.TypeTCCPacketReceivedSmallDelta,
					rtcp.TypeTCCPacketReceivedSmallDelta,
				},
			},
			deltas: []*rtcp.RecvDelta{
				{Type: rtcp.TypeTCCPacketReceivedSmallDelta, Delta: 0},
				{Type: rtcp.TypeTCCPacketReceivedSmallDelta, Delta: 0},
				{Type: rtcp.TypeTCCPacketReceivedSmallDelta, Delta: 0},
				{Type: rtcp.TypeTCCPacketReceivedSmallDelta, Delta: 0},
				{Type: rtcp.TypeTCCPacketReceivedSmallDelta, Delta: 0},
				{Type: rtcp.TypeTCCPacketReceivedSmallDelta, Delta: 0},
			},
			start: 0,
			//nolint:dupl
			acks: []Acknowledgment{
				{
					SequenceNumber: 0,
					Size:           0,
					Departure:      time.Time{},
					Arrival:        time.Time{},
				},
				{
					SequenceNumber: 1,
					Size:           0,
					Departure:      time.Time{},
					Arrival:        time.Time{},
				},
				{
					SequenceNumber: 2,
					Size:           0,
					Departure:      time.Time{},
					Arrival:        time.Time{},
				},
				{
					SequenceNumber: 3,
					Size:           0,
					Departure:      time.Time{},
					Arrival:        time.Time{},
				},
				{
					SequenceNumber: 4,
					Size:           0,
					Departure:      time.Time{},
					Arrival:        time.Time{},
				},
				{
					SequenceNumber: 5,
					Size:           0,
					Departure:      time.Time{},
					Arrival:        time.Time{},
				},
			},
			n:       6,
			refTime: time.Time{},
		},
		{
			sentTLCC: []uint16{65534, 65535, 0, 1, 2, 3},
			chunk: rtcp.StatusVectorChunk{
				PacketStatusChunk: nil,
				Type:              0,
				SymbolSize:        rtcp.TypeTCCSymbolSizeTwoBit,
				SymbolList: []uint16{
					rtcp.TypeTCCPacketReceivedSmallDelta,
					rtcp.TypeTCCPacketReceivedSmallDelta,
					rtcp.TypeTCCPacketReceivedSmallDelta,
					rtcp.TypeTCCPacketReceivedSmallDelta,
					rtcp.TypeTCCPacketNotReceived,
					rtcp.TypeTCCPacketReceivedSmallDelta,
				},
			},
			deltas: []*rtcp.RecvDelta{
				{Type: rtcp.TypeTCCPacketReceivedSmallDelta, Delta: 250},
				{Type: rtcp.TypeTCCPacketReceivedSmallDelta, Delta: 250},
				{Type: rtcp.TypeTCCPacketReceivedSmallDelta, Delta: 250},
				{Type: rtcp.TypeTCCPacketReceivedSmallDelta, Delta: 250},
				{Type: rtcp.TypeTCCPacketReceivedSmallDelta, Delta: 250},
			},
			start: 65534,
			acks: []Acknowledgment{
				{
					SequenceNumber: 65534,
					Size:           0,
					Departure:      time.Time{},
					Arrival:        time.Time{}.Add(250 * time.Microsecond),
				},
				{
					SequenceNumber: 65535,
					Size:           0,
					Departure:      time.Time{},
					Arrival:        time.Time{}.Add(500 * time.Microsecond),
				},
				{
					SequenceNumber: 0,
					Size:           0,
					Departure:      time.Time{},
					Arrival:        time.Time{}.Add(750 * time.Microsecond),
				},
				{
					SequenceNumber: 1,
					Size:           0,
					Departure:      time.Time{},
					Arrival:        time.Time{}.Add(1000 * time.Microsecond),
				},
				{
					SequenceNumber: 2,
					Size:           0,
					Departure:      time.Time{},
					Arrival:        time.Time{},
				},
				{
					SequenceNumber: 3,
					Size:           0,
					Departure:      time.Time{},
					Arrival:        time.Time{}.Add(1250 * time.Microsecond),
				},
			},
			n:       5,
			refTime: time.Time{}.Add(1250 * time.Microsecond),
		},
	}

	//nolint:dupl
	for i, tc := range cases {
		t.Run(fmt.Sprintf("%v", i), func(t *testing.T) {
			fa := NewFeedbackAdapter()

			headers := []*rtp.Header{}
			for i, nr := range tc.sentTLCC {
				headers = append(headers, &getPacketWithTransportCCExt(t, nr).Header)
				tc.acks[i].Size += headers[i].MarshalSize()
			}
			for _, h := range headers {
				assert.NoError(t, fa.OnSent(time.Time{}, h, 0, attributes))
			}

			n, refTime, _, acks, err := fa.unpackStatusVectorChunk(tc.start, time.Time{}, &tc.chunk, tc.deltas, math.MaxUint16)
			assert.NoError(t, err)
			assert.Len(t, acks, len(tc.acks))
			assert.Equal(t, tc.n, n)
			assert.Equal(t, tc.refTime, refTime)

			for i, a := range acks {
				assert.Equal(t, tc.sentTLCC[i], a.SequenceNumber)
			}
			assert.Equal(t, tc.acks, acks)
		})
	}
}

func getPacketWithTransportCCExt(t *testing.T, sequenceNumber uint16) *rtp.Packet {
	t.Helper()

	pkt := rtp.Packet{
		Header:  rtp.Header{},
		Payload: []byte{},
	}
	ext := &rtp.TransportCCExtension{
		TransportSequence: sequenceNumber,
	}
	b, err := ext.Marshal()
	assert.NoError(t, err)
	assert.NoError(t, pkt.SetExtension(hdrExtID, b))

	return &pkt
}

//nolint:maintidx,cyclop
func TestFeedbackAdapterTWCC(t *testing.T) {
	t.Run("empty", func(t *testing.T) {
		adapter := NewFeedbackAdapter()
		result, err := adapter.OnTransportCCFeedback(time.Time{}, &rtcp.TransportLayerCC{})
		assert.NoError(t, err)
		assert.Empty(t, result)
	})

	t.Run("setsCorrectReceiveTime", func(t *testing.T) {
		t0 := time.Time{}
		adapter := NewFeedbackAdapter()
		headers := []rtp.Header{}
		for i := range uint16(22) {
			pkt := getPacketWithTransportCCExt(t, i)
			headers = append(headers, pkt.Header)
			assert.NoError(
				t,
				adapter.OnSent(t0, &pkt.Header, 1200, interceptor.Attributes{TwccExtensionAttributesKey: hdrExtID}),
			)
		}
		results, err := adapter.OnTransportCCFeedback(t0, &rtcp.TransportLayerCC{
			Header:             rtcp.Header{},
			SenderSSRC:         0,
			MediaSSRC:          0,
			BaseSequenceNumber: 0,
			PacketStatusCount:  22,
			ReferenceTime:      0,
			FbPktCount:         0,
			PacketChunks: []rtcp.PacketStatusChunk{
				&rtcp.StatusVectorChunk{
					PacketStatusChunk: nil,
					Type:              rtcp.TypeTCCStatusVectorChunk,
					SymbolSize:        rtcp.TypeTCCSymbolSizeTwoBit,
					SymbolList: []uint16{
						rtcp.TypeTCCPacketReceivedSmallDelta,
						rtcp.TypeTCCPacketReceivedLargeDelta,
						rtcp.TypeTCCPacketNotReceived,
						rtcp.TypeTCCPacketNotReceived,
						rtcp.TypeTCCPacketNotReceived,
						rtcp.TypeTCCPacketNotReceived,
						rtcp.TypeTCCPacketNotReceived,
					},
				},
				&rtcp.StatusVectorChunk{
					PacketStatusChunk: nil,
					Type:              rtcp.TypeTCCStatusVectorChunk,
					SymbolSize:        rtcp.TypeTCCSymbolSizeOneBit,
					SymbolList: []uint16{
						rtcp.TypeTCCPacketReceivedSmallDelta,
						rtcp.TypeTCCPacketNotReceived,
						rtcp.TypeTCCPacketNotReceived,
						rtcp.TypeTCCPacketNotReceived,
						rtcp.TypeTCCPacketNotReceived,
						rtcp.TypeTCCPacketNotReceived,
						rtcp.TypeTCCPacketNotReceived,
						rtcp.TypeTCCPacketNotReceived,
						rtcp.TypeTCCPacketNotReceived,
						rtcp.TypeTCCPacketNotReceived,
						rtcp.TypeTCCPacketNotReceived,
						rtcp.TypeTCCPacketNotReceived,
						rtcp.TypeTCCPacketNotReceived,
						rtcp.TypeTCCPacketNotReceived,
					},
				},
				&rtcp.RunLengthChunk{
					Type:               rtcp.TypeTCCRunLengthChunk,
					PacketStatusSymbol: rtcp.TypeTCCPacketReceivedSmallDelta,
					RunLength:          1,
				},
			},
			RecvDeltas: []*rtcp.RecvDelta{
				{
					Type:  rtcp.TypeTCCPacketReceivedSmallDelta,
					Delta: 4,
				},
				{
					Type:  rtcp.TypeTCCPacketReceivedLargeDelta,
					Delta: 100,
				},
				{
					Type:  rtcp.TypeTCCPacketReceivedSmallDelta,
					Delta: 12,
				},
				{
					Type:  rtcp.TypeTCCPacketReceivedSmallDelta,
					Delta: 4,
				},
			},
		})

		assert.NoError(t, err)

		assert.NotEmpty(t, results)
		assert.Len(t, results, 22)

		assert.Contains(t, results, Acknowledgment{
			SequenceNumber: 0,
			Size:           headers[0].MarshalSize() + 1200,
			Departure:      t0,
			Arrival:        t0.Add(4 * time.Microsecond),
		})

		assert.Contains(t, results, Acknowledgment{
			SequenceNumber: 1,
			Size:           headers[1].MarshalSize() + 1200,
			Departure:      t0,
			Arrival:        t0.Add(104 * time.Microsecond),
		})

		for i := uint16(2); i < 7; i++ {
			assert.Contains(t, results, Acknowledgment{
				SequenceNumber: i,
				Size:           headers[i].MarshalSize() + 1200,
				Departure:      t0,
				Arrival:        time.Time{},
			})
		}

		assert.Contains(t, results, Acknowledgment{
			SequenceNumber: 7,
			Size:           headers[7].MarshalSize() + 1200,
			Departure:      t0,
			Arrival:        t0.Add(116 * time.Microsecond),
		})

		for i := uint16(8); i < 21; i++ {
			assert.Contains(t, results, Acknowledgment{
				SequenceNumber: i,
				Size:           headers[i].MarshalSize() + 1200,
				Departure:      t0,
				Arrival:        time.Time{},
			})
		}

		assert.Contains(t, results, Acknowledgment{
			SequenceNumber: 21,
			Size:           headers[21].MarshalSize() + 1200,
			Departure:      t0,
			Arrival:        t0.Add(120 * time.Microsecond),
		})
	})

	t.Run("doesNotCrashOnTooManyFeedbackReports", func(*testing.T) {
		adapter := NewFeedbackAdapter()
		assert.NotPanics(t, func() {
			_, err := adapter.OnTransportCCFeedback(time.Time{}, &rtcp.TransportLayerCC{
				Header:             rtcp.Header{},
				SenderSSRC:         0,
				MediaSSRC:          0,
				BaseSequenceNumber: 0,
				PacketStatusCount:  0,
				ReferenceTime:      0,
				FbPktCount:         0,
				PacketChunks: []rtcp.PacketStatusChunk{
					&rtcp.StatusVectorChunk{
						PacketStatusChunk: nil,
						Type:              rtcp.TypeTCCStatusVectorChunk,
						SymbolSize:        rtcp.TypeTCCSymbolSizeTwoBit,
						SymbolList: []uint16{
							rtcp.TypeTCCPacketReceivedSmallDelta,
							rtcp.TypeTCCPacketNotReceived,
							rtcp.TypeTCCPacketNotReceived,
							rtcp.TypeTCCPacketNotReceived,
							rtcp.TypeTCCPacketNotReceived,
							rtcp.TypeTCCPacketNotReceived,
							rtcp.TypeTCCPacketNotReceived,
						},
					},
				},
				RecvDeltas: []*rtcp.RecvDelta{
					{
						Type:  rtcp.TypeTCCPacketReceivedSmallDelta,
						Delta: 4, // 4*250us=1ms
					},
				},
			})
			assert.NoError(t, err)
		})
	})

	t.Run("worksOnSequenceNumberWrapAround", func(t *testing.T) {
		t0 := time.Time{}
		adapter := NewFeedbackAdapter()
		pkt65535 := getPacketWithTransportCCExt(t, 65535)
		pkt0 := getPacketWithTransportCCExt(t, 0)
		assert.NoError(
			t,
			adapter.OnSent(t0, &pkt65535.Header, 1200, interceptor.Attributes{TwccExtensionAttributesKey: hdrExtID}),
		)
		assert.NoError(
			t,
			adapter.OnSent(t0, &pkt0.Header, 1200, interceptor.Attributes{TwccExtensionAttributesKey: hdrExtID}),
		)

		results, err := adapter.OnTransportCCFeedback(t0, &rtcp.TransportLayerCC{
			Header:             rtcp.Header{},
			SenderSSRC:         0,
			MediaSSRC:          0,
			BaseSequenceNumber: 65535,
			PacketStatusCount:  2,
			ReferenceTime:      0,
			FbPktCount:         0,
			PacketChunks: []rtcp.PacketStatusChunk{
				&rtcp.StatusVectorChunk{
					PacketStatusChunk: nil,
					Type:              rtcp.TypeTCCStatusVectorChunk,
					SymbolSize:        rtcp.TypeTCCSymbolSizeTwoBit,
					SymbolList: []uint16{
						rtcp.TypeTCCPacketReceivedSmallDelta,
						rtcp.TypeTCCPacketReceivedSmallDelta,
						rtcp.TypeTCCPacketNotReceived,
						rtcp.TypeTCCPacketNotReceived,
						rtcp.TypeTCCPacketNotReceived,
						rtcp.TypeTCCPacketNotReceived,
						rtcp.TypeTCCPacketNotReceived,
					},
				},
			},
			RecvDeltas: []*rtcp.RecvDelta{
				{
					Type:  rtcp.TypeTCCPacketReceivedSmallDelta,
					Delta: 4,
				},
				{
					Type:  rtcp.TypeTCCPacketReceivedSmallDelta,
					Delta: 4,
				},
			},
		})
		assert.NoError(t, err)

		assert.NotEmpty(t, results)
		assert.Len(t, results, 2)
		assert.Contains(t, results, Acknowledgment{
			SequenceNumber: 65535,
			Size:           pkt65535.Header.MarshalSize() + 1200,
			Departure:      t0,
			Arrival:        t0.Add(4 * time.Microsecond),
		})
		assert.Contains(t, results, Acknowledgment{
			SequenceNumber: 0,
			Size:           pkt0.Header.MarshalSize() + 1200,
			Departure:      t0,
			Arrival:        t0.Add(8 * time.Microsecond),
		})
	})

	t.Run("ignoresPossiblyInFlightPackets", func(t *testing.T) {
		t0 := time.Time{}
		adapter := NewFeedbackAdapter()
		headers := []rtp.Header{}
		for i := range uint16(8) {
			pkt := getPacketWithTransportCCExt(t, i)
			headers = append(headers, pkt.Header)
			assert.NoError(
				t,
				adapter.OnSent(t0, &pkt.Header, 1200, interceptor.Attributes{TwccExtensionAttributesKey: hdrExtID}),
			)
		}

		results, err := adapter.OnTransportCCFeedback(t0, &rtcp.TransportLayerCC{
			Header:             rtcp.Header{},
			SenderSSRC:         0,
			MediaSSRC:          0,
			BaseSequenceNumber: 0,
			PacketStatusCount:  3,
			ReferenceTime:      0,
			FbPktCount:         0,
			PacketChunks: []rtcp.PacketStatusChunk{
				&rtcp.StatusVectorChunk{
					PacketStatusChunk: nil,
					Type:              rtcp.TypeTCCStatusVectorChunk,
					SymbolSize:        rtcp.TypeTCCSymbolSizeTwoBit,
					SymbolList: []uint16{
						rtcp.TypeTCCPacketReceivedSmallDelta,
						rtcp.TypeTCCPacketReceivedSmallDelta,
						rtcp.TypeTCCPacketReceivedSmallDelta,
						rtcp.TypeTCCPacketNotReceived,
						rtcp.TypeTCCPacketNotReceived,
						rtcp.TypeTCCPacketNotReceived,
						rtcp.TypeTCCPacketNotReceived,
					},
				},
			},
			RecvDeltas: []*rtcp.RecvDelta{
				{
					Type:  rtcp.TypeTCCPacketReceivedSmallDelta,
					Delta: 4, // 4*250us=1ms
				},
				{
					Type:  rtcp.TypeTCCPacketReceivedSmallDelta,
					Delta: 4, // 4*250us=1ms
				},
				{
					Type:  rtcp.TypeTCCPacketReceivedSmallDelta,
					Delta: 4, // 4*250us=1ms
				},
			},
		})
		assert.NoError(t, err)
		assert.Len(t, results, 3)
		for i := range uint16(3) {
			assert.Contains(t, results, Acknowledgment{
				SequenceNumber: i,
				Size:           headers[i].MarshalSize() + 1200,
				Departure:      t0,
				Arrival:        t0.Add(time.Duration((i + 1)) * 4 * time.Microsecond),
			})
		}
	})

	t.Run("runLengthChunk", func(t *testing.T) {
		adapter := NewFeedbackAdapter()
		t0 := time.Time{}
		for i := range uint16(20) {
			pkt := getPacketWithTransportCCExt(t, i)
			assert.NoError(
				t,
				adapter.OnSent(t0, &pkt.Header, 1200, interceptor.Attributes{TwccExtensionAttributesKey: hdrExtID}),
			)
		}
		packets, err := adapter.OnTransportCCFeedback(t0, &rtcp.TransportLayerCC{
			Header:             rtcp.Header{},
			SenderSSRC:         0,
			MediaSSRC:          0,
			BaseSequenceNumber: 0,
			PacketStatusCount:  3,
			ReferenceTime:      0,
			FbPktCount:         0,
			PacketChunks: []rtcp.PacketStatusChunk{
				&rtcp.RunLengthChunk{
					PacketStatusSymbol: rtcp.TypeTCCPacketReceivedSmallDelta,
					RunLength:          3,
				},
			},
			RecvDeltas: []*rtcp.RecvDelta{
				{
					Type:  rtcp.TypeTCCPacketReceivedSmallDelta,
					Delta: 4,
				},
				{
					Type:  rtcp.TypeTCCPacketReceivedSmallDelta,
					Delta: 4,
				},
				{
					Type:  rtcp.TypeTCCPacketReceivedSmallDelta,
					Delta: 4,
				},
			},
		})

		assert.NoError(t, err)
		assert.Len(t, packets, 3)
	})

	t.Run("statusVectorChunk", func(t *testing.T) {
		adapter := NewFeedbackAdapter()
		t0 := time.Time{}
		for i := range uint16(20) {
			pkt := getPacketWithTransportCCExt(t, i)
			assert.NoError(
				t,
				adapter.OnSent(t0, &pkt.Header, 1200, interceptor.Attributes{TwccExtensionAttributesKey: hdrExtID}),
			)
		}
		packets, err := adapter.OnTransportCCFeedback(t0, &rtcp.TransportLayerCC{
			Header:             rtcp.Header{},
			SenderSSRC:         0,
			MediaSSRC:          0,
			BaseSequenceNumber: 0,
			PacketStatusCount:  3,
			ReferenceTime:      0,
			FbPktCount:         0,
			PacketChunks: []rtcp.PacketStatusChunk{
				&rtcp.StatusVectorChunk{
					SymbolSize: rtcp.TypeTCCSymbolSizeOneBit,
					SymbolList: []uint16{
						rtcp.TypeTCCPacketReceivedSmallDelta,
						rtcp.TypeTCCPacketReceivedSmallDelta,
						rtcp.TypeTCCPacketReceivedSmallDelta,
						rtcp.TypeTCCPacketNotReceived,
						rtcp.TypeTCCPacketNotReceived,
						rtcp.TypeTCCPacketNotReceived,
						rtcp.TypeTCCPacketNotReceived,
						rtcp.TypeTCCPacketNotReceived,
						rtcp.TypeTCCPacketNotReceived,
						rtcp.TypeTCCPacketNotReceived,
						rtcp.TypeTCCPacketNotReceived,
						rtcp.TypeTCCPacketNotReceived,
						rtcp.TypeTCCPacketNotReceived,
						rtcp.TypeTCCPacketNotReceived,
					},
				},
			},
			RecvDeltas: []*rtcp.RecvDelta{
				{
					Type:  rtcp.TypeTCCPacketReceivedSmallDelta,
					Delta: 4,
				},
				{
					Type:  rtcp.TypeTCCPacketReceivedSmallDelta,
					Delta: 4,
				},
				{
					Type:  rtcp.TypeTCCPacketReceivedSmallDelta,
					Delta: 4,
				},
			},
		})

		assert.NoError(t, err)
		assert.Len(t, packets, 3)
	})

	t.Run("mixedRunLengthAndStatusVector", func(t *testing.T) {
		adapter := NewFeedbackAdapter()

		t0 := time.Time{}
		for i := range uint16(20) {
			pkt := getPacketWithTransportCCExt(t, i)
			assert.NoError(
				t,
				adapter.OnSent(t0, &pkt.Header, 1200, interceptor.Attributes{TwccExtensionAttributesKey: hdrExtID}),
			)
		}

		//nolint:dupl
		packets, err := adapter.OnTransportCCFeedback(t0, &rtcp.TransportLayerCC{
			Header:             rtcp.Header{},
			SenderSSRC:         0,
			MediaSSRC:          0,
			BaseSequenceNumber: 0,
			PacketStatusCount:  10,
			ReferenceTime:      0,
			FbPktCount:         0,
			PacketChunks: []rtcp.PacketStatusChunk{
				&rtcp.StatusVectorChunk{
					SymbolSize: rtcp.TypeTCCSymbolSizeTwoBit,
					SymbolList: []uint16{
						rtcp.TypeTCCPacketReceivedSmallDelta,
						rtcp.TypeTCCPacketReceivedSmallDelta,
						rtcp.TypeTCCPacketReceivedSmallDelta,
						rtcp.TypeTCCPacketNotReceived,
						rtcp.TypeTCCPacketNotReceived,
						rtcp.TypeTCCPacketNotReceived,
						rtcp.TypeTCCPacketNotReceived,
					},
				},
				&rtcp.RunLengthChunk{
					PacketStatusSymbol: rtcp.TypeTCCPacketReceivedSmallDelta,
					RunLength:          3,
				},
			},
			RecvDeltas: []*rtcp.RecvDelta{
				{
					Type:  rtcp.TypeTCCPacketReceivedSmallDelta,
					Delta: 4,
				},
				{
					Type:  rtcp.TypeTCCPacketReceivedSmallDelta,
					Delta: 4,
				},
				{
					Type:  rtcp.TypeTCCPacketReceivedSmallDelta,
					Delta: 4,
				},
				{
					Type:  rtcp.TypeTCCPacketReceivedSmallDelta,
					Delta: 4,
				},
				{
					Type:  rtcp.TypeTCCPacketReceivedSmallDelta,
					Delta: 4,
				},
				{
					Type:  rtcp.TypeTCCPacketReceivedSmallDelta,
					Delta: 4,
				},
			},
		})
		assert.NoError(t, err)
		assert.Len(t, packets, 10)
	})

	t.Run("ignoresChunksBeyondPacketStatusCount", func(t *testing.T) {
		t0 := time.Time{}
		adapter := NewFeedbackAdapter()
		for i := range uint16(10) {
			pkt := getPacketWithTransportCCExt(t, i)
			assert.NoError(
				t,
				adapter.OnSent(t0, &pkt.Header, 1200, interceptor.Attributes{TwccExtensionAttributesKey: hdrExtID}),
			)
		}

		// The count ends with the run-length chunk; the trailing status
		// vector covers packets 3..9, all in the history, and must be
		// ignored entirely.
		results, err := adapter.OnTransportCCFeedback(t0, &rtcp.TransportLayerCC{
			BaseSequenceNumber: 0,
			PacketStatusCount:  3,
			PacketChunks: []rtcp.PacketStatusChunk{
				&rtcp.RunLengthChunk{
					Type:               rtcp.TypeTCCRunLengthChunk,
					PacketStatusSymbol: rtcp.TypeTCCPacketReceivedSmallDelta,
					RunLength:          3,
				},
				&rtcp.StatusVectorChunk{
					Type:       rtcp.TypeTCCStatusVectorChunk,
					SymbolSize: rtcp.TypeTCCSymbolSizeTwoBit,
					SymbolList: []uint16{
						rtcp.TypeTCCPacketNotReceived,
						rtcp.TypeTCCPacketNotReceived,
						rtcp.TypeTCCPacketNotReceived,
						rtcp.TypeTCCPacketNotReceived,
						rtcp.TypeTCCPacketNotReceived,
						rtcp.TypeTCCPacketNotReceived,
						rtcp.TypeTCCPacketNotReceived,
					},
				},
			},
			RecvDeltas: []*rtcp.RecvDelta{
				{Type: rtcp.TypeTCCPacketReceivedSmallDelta, Delta: 4},
				{Type: rtcp.TypeTCCPacketReceivedSmallDelta, Delta: 4},
				{Type: rtcp.TypeTCCPacketReceivedSmallDelta, Delta: 4},
			},
		})
		assert.NoError(t, err)
		assert.Len(t, results, 3)
		for _, r := range results {
			assert.False(t, r.Arrival.IsZero(), "packet %d must not be reported lost", r.SequenceNumber)
		}
	})

	t.Run("skipsPacketsEvictedFromHistory", func(t *testing.T) {
		t0 := time.Time{}
		adapter := NewFeedbackAdapter()
		for i := range uint16(251) {
			pkt := getPacketWithTransportCCExt(t, i)
			assert.NoError(
				t,
				adapter.OnSent(t0, &pkt.Header, 1200, interceptor.Attributes{TwccExtensionAttributesKey: hdrExtID}),
			)
		}

		results, err := adapter.OnTransportCCFeedback(t0, &rtcp.TransportLayerCC{
			BaseSequenceNumber: 0,
			PacketStatusCount:  251,
			PacketChunks: []rtcp.PacketStatusChunk{
				&rtcp.RunLengthChunk{
					Type:               rtcp.TypeTCCRunLengthChunk,
					PacketStatusSymbol: rtcp.TypeTCCPacketReceivedSmallDelta,
					RunLength:          251,
				},
			},
			RecvDeltas: func() []*rtcp.RecvDelta {
				ret := make([]*rtcp.RecvDelta, 251)
				for i := range ret {
					ret[i] = &rtcp.RecvDelta{Type: rtcp.TypeTCCPacketReceivedSmallDelta, Delta: 4}
				}

				return ret
			}(),
		})
		assert.NoError(t, err)
		assert.Len(t, results, 250)
		assert.Equal(t, uint16(1), results[0].SequenceNumber)
		assert.False(t, results[0].Arrival.IsZero())
	})

	t.Run("skipsEvictedPacketWithoutDelta", func(t *testing.T) {
		for name, chunks := range map[string][]rtcp.PacketStatusChunk{
			"runLength": {
				&rtcp.RunLengthChunk{PacketStatusSymbol: rtcp.TypeTCCPacketReceivedWithoutDelta, RunLength: 1},
				&rtcp.RunLengthChunk{PacketStatusSymbol: rtcp.TypeTCCPacketReceivedSmallDelta, RunLength: 1},
			},
			"statusVector": {&rtcp.StatusVectorChunk{
				SymbolSize: rtcp.TypeTCCSymbolSizeTwoBit,
				SymbolList: []uint16{rtcp.TypeTCCPacketReceivedWithoutDelta, rtcp.TypeTCCPacketReceivedSmallDelta},
			}},
		} {
			t.Run(name, func(t *testing.T) {
				adapter := NewFeedbackAdapter()
				pkt := getPacketWithTransportCCExt(t, 1)
				assert.NoError(t, adapter.OnSent(time.Time{}, &pkt.Header, 1200,
					interceptor.Attributes{TwccExtensionAttributesKey: hdrExtID}))
				results, err := adapter.OnTransportCCFeedback(time.Time{}, &rtcp.TransportLayerCC{
					PacketStatusCount: 2,
					PacketChunks:      chunks,
					RecvDeltas:        []*rtcp.RecvDelta{{Type: rtcp.TypeTCCPacketReceivedSmallDelta, Delta: 250}},
				})
				if assert.NoError(t, err) && assert.Len(t, results, 1) {
					assert.Equal(t, uint16(1), results[0].SequenceNumber)
					assert.Equal(t, time.Time{}.Add(250*time.Microsecond), results[0].Arrival)
				}
			})
		}
	})

	t.Run("doesNotcrashOnInvalidTWCCPacket", func(t *testing.T) {
		adapter := NewFeedbackAdapter()

		t0 := time.Time{}
		for i := uint16(1008); i < 1030; i++ {
			pkt := getPacketWithTransportCCExt(t, i)
			assert.NoError(
				t,
				adapter.OnSent(t0, &pkt.Header, 1200, interceptor.Attributes{TwccExtensionAttributesKey: hdrExtID}),
			)
		}

		//nolint:dupl
		assert.NotPanics(t, func() {
			packets, err := adapter.OnTransportCCFeedback(t0, &rtcp.TransportLayerCC{
				Header:             rtcp.Header{},
				SenderSSRC:         0,
				MediaSSRC:          0,
				BaseSequenceNumber: 1008,
				PacketStatusCount:  8,
				ReferenceTime:      278,
				FbPktCount:         170,
				PacketChunks: []rtcp.PacketStatusChunk{
					&rtcp.StatusVectorChunk{
						SymbolSize: rtcp.TypeTCCSymbolSizeTwoBit,
						SymbolList: []uint16{
							rtcp.TypeTCCPacketReceivedSmallDelta,
							rtcp.TypeTCCPacketReceivedSmallDelta,
							rtcp.TypeTCCPacketReceivedSmallDelta,
							rtcp.TypeTCCPacketReceivedSmallDelta,
							rtcp.TypeTCCPacketReceivedSmallDelta,
							rtcp.TypeTCCPacketReceivedSmallDelta,
							rtcp.TypeTCCPacketNotReceived,
						},
					},
					&rtcp.RunLengthChunk{
						PacketStatusSymbol: rtcp.TypeTCCPacketReceivedSmallDelta,
						RunLength:          5632,
					},
				},
				RecvDeltas: []*rtcp.RecvDelta{
					{
						Type:  rtcp.TypeTCCPacketReceivedSmallDelta,
						Delta: 25000,
					},
					{
						Type:  rtcp.TypeTCCPacketReceivedSmallDelta,
						Delta: 0,
					},
					{
						Type:  rtcp.TypeTCCPacketReceivedSmallDelta,
						Delta: 29500,
					},
					{
						Type:  rtcp.TypeTCCPacketReceivedSmallDelta,
						Delta: 16750,
					},
					{
						Type:  rtcp.TypeTCCPacketReceivedSmallDelta,
						Delta: 23500,
					},
					{
						Type:  rtcp.TypeTCCPacketReceivedSmallDelta,
						Delta: 0,
					},
				},
			})
			assert.Error(t, err)
			assert.Empty(t, packets)
		})
	})
}

func TestFeedbackAdapterTWCC_SparseRun(t *testing.T) {
	for _, symbol := range []uint16{rtcp.TypeTCCPacketNotReceived, rtcp.TypeTCCPacketReceivedWithoutDelta} {
		adapter := NewFeedbackAdapter()
		for _, seq := range []uint16{65534, 0, 8188, 8190, 8191, 8193} {
			adapter.history.add(Acknowledgment{SequenceNumber: seq, Size: 100})
		}
		adapter.history.add(Acknowledgment{SSRC: 1, SequenceNumber: 0})
		feedback := &rtcp.TransportLayerCC{
			BaseSequenceNumber: 65534, PacketStatusCount: 8195, ReferenceTime: 1,
			PacketChunks: []rtcp.PacketStatusChunk{
				&rtcp.RunLengthChunk{PacketStatusSymbol: symbol, RunLength: 8191},
				&rtcp.RunLengthChunk{PacketStatusSymbol: rtcp.TypeTCCPacketReceivedLargeDelta, RunLength: 2},
				&rtcp.StatusVectorChunk{SymbolList: []uint16{
					rtcp.TypeTCCPacketReceivedWithoutDelta, rtcp.TypeTCCPacketReceivedSmallDelta, rtcp.TypeTCCPacketNotReceived,
				}},
			},
			RecvDeltas: []*rtcp.RecvDelta{{Delta: 1000}, {Delta: -250}, {Delta: 500}},
		}
		acks, err := adapter.OnTransportCCFeedback(time.Time{}, feedback)
		require.NoError(t, err)
		require.Equal(t, []Acknowledgment{
			{SequenceNumber: 65534, Size: 100},
			{SequenceNumber: 0, Size: 100},
			{SequenceNumber: 8188, Size: 100},
			{SequenceNumber: 8190, Size: 100, Arrival: time.Time{}.Add(64*time.Millisecond + 750*time.Microsecond)},
			{SequenceNumber: 8191, Size: 100},
		}, acks)
	}
}

func BenchmarkFeedbackAdapterTWCCRunLength(b *testing.B) {
	for _, count := range []uint16{8191, 65535} {
		b.Run(fmt.Sprint(count), func(b *testing.B) {
			adapter := NewFeedbackAdapter()
			for seq := range uint16(250) {
				adapter.history.add(Acknowledgment{SequenceNumber: seq})
			}
			feedback := &rtcp.TransportLayerCC{PacketStatusCount: count}
			for remaining := count; remaining > 0; {
				run := min(remaining, 8191)
				feedback.PacketChunks = append(feedback.PacketChunks, &rtcp.RunLengthChunk{RunLength: run})
				remaining -= run
			}
			b.ReportAllocs()
			b.ResetTimer()
			for range b.N {
				_, _ = adapter.OnTransportCCFeedback(time.Time{}, feedback)
			}
		})
	}
}

func TestFeedbackAdapterTWCCReferenceRollover(t *testing.T) {
	for _, references := range [][]int64{
		{(1 << 24) - 2, (1 << 24) - 1, 1 << 24, (1 << 24) - 1, (1 << 24) + 1},
		{0, -1, 1},
	} {
		adapter := NewFeedbackAdapter()
		for seq, reference := range references {
			packet := getPacketWithTransportCCExt(t, uint16(seq)) //nolint:gosec // Small test sequence.
			require.NoError(t, adapter.OnSent(time.Time{}, &packet.Header, 1200,
				interceptor.Attributes{TwccExtensionAttributesKey: hdrExtID}))
			acks, err := adapter.OnTransportCCFeedback(time.Time{}, &rtcp.TransportLayerCC{
				BaseSequenceNumber: uint16(seq), //nolint:gosec // Small test sequence.
				PacketStatusCount:  1,
				ReferenceTime:      uint32(reference & 0xffffff), //nolint:gosec // Masked to 24 bits.
				PacketChunks: []rtcp.PacketStatusChunk{&rtcp.RunLengthChunk{
					PacketStatusSymbol: rtcp.TypeTCCPacketReceivedSmallDelta, RunLength: 1,
				}},
				RecvDeltas: []*rtcp.RecvDelta{{Type: rtcp.TypeTCCPacketReceivedSmallDelta, Delta: 250}},
			})
			require.NoError(t, err)
			require.Len(t, acks, 1)
			require.Equal(t, time.Time{}.Add(time.Duration(reference)*64*time.Millisecond+250*time.Microsecond), acks[0].Arrival)
		}
	}
}
